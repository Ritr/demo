import React, { useState, useEffect } from "react";

import { useRequest } from "ahooks";
import { Page } from "@/interface/base";
import Search from "./components/search";
import List from "./components/list";
import type { QueryParams, SearchParams, ResponseEntity } from "./interface";
import { getList } from "./api";
import "./index.scss";
import { Card } from "antd";
const index = () => {
  const [queryParams, setQueryParams] = useState<QueryParams>({
    pageNum: 1,
    pageSize: 10,
  });
  const [list, setList] = useState<Array<ResponseEntity>>([]);
  const [total, setTotal] = useState<number>(0);
  const change = (params: SearchParams | Page) => {
    setQueryParams({ ...queryParams, ...params });
  };

  const getListHandle = useRequest(getList, {
    manual: true,
    debounceInterval: 300,
  });
  const refresh = () => {
    getListHandle.run(queryParams);
  };
  useEffect(() => {
    getListHandle.run(queryParams);
  }, [queryParams]);
  useEffect(() => {
    let data = getListHandle.data;
    if (data) {
      setList(data.data.list);
      setTotal(data.data.total);
    }
  }, [getListHandle.data]);
  return (
    <div>
      <Card>
        <Search change={change}></Search>
        <div className="space"></div>
        <List
          change={change}
          dataSource={list}
          total={total}
          loading={getListHandle.loading}
          refresh={refresh}
        ></List>
      </Card>
    </div>
  );
};

export default index;
