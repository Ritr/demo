import React, { useState, useEffect } from "react";
import { Input, Form, Select, Row, Col, Button} from "antd";
import type { SearchParams } from "../interface";
interface Props {
  change: (searchParams:SearchParams)=>void;
}
export default (props: Props) => {
  const change = (allValues:any)=>{
    let values = { ...allValues };
    values.startCreateTime = "";
    values.endCreateTime = "";
    if (allValues.createTime) {
      let time = allValues.createTime as Array<moment.Moment>;
      values.startCreateTime = time[0].format("YYYY/MM/DD HH:mm:ss");
      values.endCreateTime = time[1].format("YYYY/MM/DD HH:mm:ss");
    }
    props.change(values as SearchParams);
  }
  const [form] = Form.useForm();
  const reset = () => {
    form.resetFields();
  };
  return (
    <Row justify="space-between" className="search">
      <Col>
        <Form
          layout="inline"
          form={form}
          onValuesChange={(changedValues, allValues) => {
            change(allValues);
          }}
        >
          <Form.Item label="搜索" name="planName">
            <Input placeholder="任务名称" allowClear />
          </Form.Item>
        </Form>
      </Col>
      <Col>
        <Button type="primary" onClick={reset}>
          重置
        </Button>
      </Col>
    </Row>
  );
};
