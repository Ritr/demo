import React, { useEffect, useState } from "react";
import type { ResponseEntity } from "../interface";
import { Page } from "@/interface/base";
import { Button, Row, Col, Table, Card } from "antd";
import { PlusOutlined } from "@ant-design/icons";
interface Props {
  dataSource: Array<ResponseEntity>;
  change: (page: Page) => void;
  loading?: boolean;
  total: number;
  refresh: () => void;
}
const list = (props: Props) => {
  const { dataSource, loading, total, change, refresh } = props;
  const pageChange = (pageNum: number, pageSize: number = 0) => {
    change({ pageSize: pageSize, pageNum: pageNum });
  };

  const columns = [
    {
      title: "计划名称",
      dataIndex: "planName",
      key: "planName",
    },
    {
      title: "操作",
      key: "id",
      render: (item: ResponseEntity) => {
        return (
          <div>
            <span>操作</span>
          </div>
        );
      },
    },
  ];
  return (
    <Card>
      <Row justify="space-between">
        <Col>
          <span>共{total}条</span>
        </Col>
        <Col>
          <Button className="ant-btn-icon">
            <PlusOutlined />
            操作按钮
          </Button>
        </Col>
      </Row>
      <Table
        className="table"
        columns={columns}
        dataSource={dataSource}
        loading={loading}
        rowKey="id"
        pagination={{ total: total, onChange: pageChange }}
      ></Table>
    </Card>
  );
};

export default list;
