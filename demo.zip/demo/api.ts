import request from "@/utils/request";
import type { QueryParams } from "./interface";
export const getList = (queryParams: QueryParams) => {
    return request("/api", "POST", queryParams);
};