import { Page } from "@/interface/base";
// search查询参数
export interface SearchParams {
    key?:string
}
// 全部查询参数
export interface QueryParams extends SearchParams, Page { 
}
// 基本输出
export interface BaseResponse {
}
// 列表输出
export interface ResponseEntity extends BaseResponse {
}
// 单项详情输出
export interface ResponseDetail extends BaseResponse {
}